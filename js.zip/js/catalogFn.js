function putInBasket(id){
	var tovarCnt = $('#catalogCnt_'+id).val();
	var basket = [], basketArray, goodsId;
	var inBasket = false;
	var tovarName = $('#tovar_'+id).text();
	var tovarObj;
	
	if(tovarCnt <= 0){ alert('Поле пустое'); return false; }
	
	tovarObj = {
		id: id,
		name: tovarName,
		cnt: tovarCnt
	};
	
	basket = $.cookie('basket');
	if(basket == null) { basket = []; }
	else{
		basket = $.parseJSON(basket);
	}
	
	for(var i=0; i < basket.length; i++){
		goodsId = basket[i]['id'];
		
		if(goodsId == id){
			inBasket = true;
			break;
		}
	}
	if(!inBasket){
		basket.push(tovarObj);
		$('#basketLink').text('Корзина ['+basket.length+']');
		alert('Добавлено');
	}else{
		alert('Товар уже в корзине');
	}
	
	
	basket = $.toJSON(basket);
		
	$.cookie('basket', basket, {path: "/"});
	
	return false;
}

function countBasket(){
	var basket, goodsId, newCnt;
	
	basket = $.cookie('basket');
	if(basket == null) { basket = []; }
	else{
		basket = $.parseJSON(basket);
	}
	
	for(var i=0; i < basket.length; i++){
		goodsId = basket[i]['id'];
		newCnt = $('#productInBasketCnt_'+goodsId).val();
		
		basket[i]['cnt'] = newCnt;
	}
	basket = $.toJSON(basket);
	$.cookie('basket', basket, {path: "/"});
	window.location = window.location;
}

$(document).ready(function(){
	$('.catalogCnt input.textField').keyup(function(){ //Разрешено вводить только цифры
		var value = $(this).val();
		value = value.replace(/[^\d\.]/gi, '');
		$(this).val(value);
	});
});

function sendOrder(e){
    if($('#Manager').val() == 0){
        alert('Пожалуйста, выберите менеджера!');
    }else{
        $.cookie('manager', $('#Manager').val(), {path: "/"});
        window.location = $(e).attr('href');
    }
    
    return false;
}