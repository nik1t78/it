

(function($){
    $.fn.nestedArray = function(){
        return nestedTree(this, 0);
            function nestedTree(o, startDepthCount) {
                
    			var sDepth = startDepthCount || 0,
    			    ret = new Array,
    			    left = 1;
    			$(o).children("li").each(function () {
    				left = _recursiveArray(this, sDepth + 1, left);
    			});
    
    			ret = ret.sort(function(a,b){ return (a.left - b.left); });
    			return ret;
    
    			function _recursiveArray(item, depth, left) {
    				var right = left + 1,
    				    id,
    				    pid;
    
    				if ($(item).children("ul").children("li").length > 0) {
    					depth ++;
    					$(item).children("ul").children("li").each(function () {
    						right = _recursiveArray($(this), depth, right);
    					});
    					depth --;
    				}
    
    				id = ($(item).attr("id")).match((/(.+)[-=_](.+)/));
    
    				if (depth === sDepth + 1) {
    					pid = 0;
    				} else {
    					var parentItem = ($(item).parent("ul")
    						.parent("li")
    						.attr(o.attribute || "id"))
    						.match(o.expression || (/(.+)[-=_](.+)/));
    					pid = parentItem[2];
    				}
    
    				if (id) {
    						ret.push({"id": id[2], "parent_id": pid, "level": depth, "lft": left, "rgt": right});
    				}
    				left = right + 1;
    				return left;
    			}
    		}
    };
    
})(jQuery);