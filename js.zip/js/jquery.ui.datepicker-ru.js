/* Russian initialisation for the jQuery UI date picker plugin. */
/* Written by Mikhail Alferov (alferovmv@gmail.com) */
jQuery(function($){
	$.datepicker.regional['ru'] = {
		closeText: 'Закрыть',
		prevText: 'Предыдущий',
		nextText: 'Следующий',
		currentText: 'Сегодня',
		monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
		'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
		monthNamesShort: ['Янв.','Февр.','Март','Апр.','Май','Июнь',
		'Июль','Авг.','Сент.','Окт.','Ноя.','Дек.'],
		dayNames: ['Воскресенье', 'Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
		dayNamesShort: ['Вс.','Пн.','Вт.','Ср.','Чт.','Пт.','Сб.'],
		dayNamesMin: ['В','П','В','С','Ч','П','С'],
		weekHeader: 'Нед.',
		dateFormat: 'dd/mm/yy',
		firstDay: 1,
		isRTL: false,
		showMonthAfterYear: false,
		yearSuffix: ''};
	$.datepicker.setDefaults($.datepicker.regional['ru']);
});
