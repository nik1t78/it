<?php

/**
 * ThroughMenu class file.
 *
 */

/**
 * ThroughMenu наследует класс CMenu и выводит многоуровневое меню, используя HTML списки.
 *
 * ThroughMenu получает из модели Pages элементы первого и второго уровней, формирует из них
 * массив и передает его классу CMenu.
 *
 * The following example shows how to use ThroughMenu:
 * <pre>
 * $this->widget('ThroughMenu');
 * </pre>
 *
 */

Yii::import('zii.widgets.CMenu');

class ThroughMenu extends CMenu{
    
	/**
	 * Получаем из модели элементы первого и второго уровней
	 */
    protected function getItems(){
        $model=Pages::model()->order_by_id()->findAll('level=:level AND id!=1', array(':level'=>2));
        $modelSize = count($model);
        $url = '';
        if($modelSize == 0){ //массив пуст, записи не найдены
            echo 'Ничего не нашлось';
        }else{
            $this->items[] = array('label'=>'Главная', 'url'=>'/'); //статическая ссылка на главную
            foreach($model as $item){ //проходим циклом по всем полученным из БД элементам 1-го уровня
                if($item->url != ''){
                    $url = $item->url;
                }else{
                    $url = '/'.$item->name;
                }
                
                $pages = Pages::model()->order_by_id()->findAll('level=:level AND parent_id=:parent_id', array(':level'=>3, ':parent_id'=>$item->id)); // получаем дочерние элементы 2-го уровня для каждого эл-та 1-го уровня
                $subItems = array();
                foreach($pages as $page){ 
                    if($item->url == ''){
                        if($page->url != ''){
                            $url2 = $page->url;
                        }else{
                            $url2 = $url.'/'.$page->name;
                        }
                    }
                    $subItems[] = array('label'=>$page->title, 'url'=>array($url2));
                }   
                $existsSub = count($subItems) > 0?' <span class="existsSub"></span>':'';
                $this->items[] = array('label'=>$item->title.$existsSub, 'url'=>array($url), 'items'=>$subItems);
            }/**
            $this->items[] = array('label'=>'О компании', 'url'=>array('/site/page', 'view'=>'about'));
            $this->items[] = array('label'=>'Информация', 'url'=>array('/site/contact'));
            $this->items[] = array('label'=>'Услуги', 'url'=>array('/site/contact'));
            $this->items[] = array('label'=>'Контакты', 'url'=>array('/site/contact'));**/
        }
		
    }
    public function init(){
        $this->activeCssClass = 'curr';
        $this->getItems();
        /** вызывается функция, формирующая массив $this->items **/
        parent::init();
    }
}
