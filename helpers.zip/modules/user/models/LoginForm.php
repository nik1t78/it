<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class LoginForm extends CFormModel
{
	public $login;
	public $password;
	public $rememberMe;

	private $_identity;

	/**
	 * Declares the validation rules.
	 * The rules state that username and password are required,
	 * and password needs to be authenticated.
	 */
	public function rules()
	{
		return array(
			// username and password are required
			array('login, password', 'required'),
			// rememberMe needs to be a boolean
			array('rememberMe', 'boolean'),
			// password needs to be authenticated
			array('password', 'authenticate'),
		);
	}

	/**
	 * Declares attribute labels.
	 */
	public function attributeLabels()
	{
		return array(
			'rememberMe'=> Yii::t('user', 'Запомнить меня'),
			'login' => Yii::t('user', 'Логин'),
			'full_name' => Yii::t('user', 'Полное имя'),
			'email' => Yii::t('user', 'E-mail'),
			'password' => Yii::t('user', 'Пароль'),
		);
	}

	/**
	 * Authenticates the password.
	 * This is the 'authenticate' validator as declared in rules().
	 */
	public function authenticate($attribute,$params)
	{
            if(!$this->hasErrors())
            {
		$this->_identity=new UserIdentity($this->login,$this->password);
                
		if(!$this->_identity->authenticate()){
                    if($this->_identity->errorCode === 3)
			$this->addError('', Yii::t('user', 'Ваша учетная запись заблокирована либо еще не активирована администратором.'));
                    else
			$this->addError('password', Yii::t('user', 'Логин или пароль введены неверно!')); 
		}
                else {           
                    $duration = $this->rememberMe ? Yii::app()->params['cookie_lifetime'] : 0; //Если стоит галочка "запомнить меня", устанавливаем cookie на срок, указанный в параметрах
                    Yii::app()->user->login($this->_identity, $duration);
                }
            }
	}

	/**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
     /*
	public function login()
	{
		if($this->_identity===null)
		{
			$this->_identity=new UserIdentity($this->username,$this->password);
			$this->_identity->authenticate();
		}
		if($this->_identity->errorCode===UserIdentity::ERROR_NONE)
		{
			$duration=$this->rememberMe ? 3600*24*30 : 0; // 30 days
			Yii::app()->user->login($this->_identity,$duration);
			return true;
		}
		else
			return false;
	}
      * 
      */
}
