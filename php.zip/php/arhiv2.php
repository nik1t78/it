<?
if (isset($_GET['dates'])) {$dates =$_GET['dates']; if ($dates == '') { unset($dates);}}


 $conn = @mysql_connect("localhost", "root", "");
    mysql_query ('SET NAMES utf8');
    mysql_query ('SET CHARACTER SET utf8');
if (!$conn)
  die("Error connecting to MySQL: " . mysql_error());

if (!mysql_select_db("cal", $conn))
  die("Error selecting Head First database: " . mysql_error());
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Архив новостей</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link type="text/css" rel="stylesheet" href="css/chosen.css" />
<link href="css/jquery.fancybox.css" rel="stylesheet" />
<link href="css/jquery.formstyler.css" rel="stylesheet" />
<link href="css/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="css/my.css" />
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script type="text/javascript" src="js/ui.datepicker-ru.js"></script>

<!--[if lte IE 8]>
<script type="text/javascript" src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<link type="text/css" href="css/ie.css" rel="stylesheet" />
<script src="http://ie7-js.googlecode.com/svn/version/2.0(beta3)/IE7-squish.js" type="text/javascript"></script>
<![endif]-->
<!--[if lte IE 6]>
<link rel="stylesheet" type="text/css" media="screen, projection" href="css/ie6.css" />
	<script type="text/javascript">
		var m = document.uniqueID
	&& document.compatMode
	&& !window.XMLHttpRequest
	&& document.execCommand;
	try{
		 if(!!m)
		  {
			 m("BackgroundImageCache", false, true)
		  }
	   }
	   catch(oh){};
	</script>
<![endif]-->

</head> 
<body>
 <div id="wrap">
 <div class="container">
  <header id="header">
  		<ul id="langs" class="none">
			<li><a href="#" id="rus"></a></li>
			<li><a href="#" id="eng"></a></li>
		</ul>
  <div class="row-fluid">
	<div class="span5">
		<a class="brand pull-left" href="/"><img src="img/logo.png" alt="logo" /></a>
		<p><strong>Департамент&nbsp;территориального<br />управления&nbsp;администрации<br />города&nbsp;Липецка</strong></p>
		<div class="clearfix"></div>
		<p id="gcr-logo" class="text-center pull-left"><img src="img/gcr.png" alt="Городской центр рекламы" /></p>
		<p><strong>Городской центр<br />рекламы</strong></p>
		<div class="clearfix"></div>
	</div>
	<div class="span4">
		<address>398059, г.Липецк, ул.Советская, 68<br /><b>8(4742)</b> 90-83-01<br /><a class="mail" href="mailto:connect@cominfo.lipetsk.ru">connect@cominfo.lipetsk.ru</a></address>
		<address>398050, г.Липецк, ул.Желябова, д.17<br /><b>(4742)</b> 27-68-65, <b>(4742)</b> 27-49-66<br /><a class="mail" href="mailto:lgcr@lgcr.ru">lgcr@lgcr.ru</a></address>
	</div>
	<div class="span3">
		<p class="text-right">
		<a href="/"><img src="img/home.png" alt="home" /></a>
		<a href="#"><img src="img/sitemap.png" alt="home" /></a>
		</p>
		<p class="text-right"><a href="#" id="login">Вход на сайт или регистрация</a></p>
	</div>
	</div>
  </header>
<nav class="navbar">
  <div class="navbar-inner">
   <div class="row-fluid">
    <ul class="nav span8" id="topnav">
      <li class="active dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Депортамент<b class="caret"></b></a>
		  <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
		  <li><a href="#">Члены департамента</a></li>
		  <li><a href="#">Председатели</a></li>
		  <li><a href="#">Гос. служащие</a></li>
		  <li><a href="#">Постановления</a></li>
		  <li><a href="#">Документы</a></li>
		  </ul>
	  </li>
      <li><a href="#">Центр рекламы</a></li>
      <li><a href="#">Программы проекты</a></li>
      <li><a href="#">Услуги</a></li>
      <li><a href="#">Контакты</a></li>
	</ul>
	<div class="span4">
	<form class="navbar-form form-search">
		<i class="icon-search"></i>
		<input type="text" class="input-block-level" placeholder="Поиск по сайту" />
		<button type="submit" class="btn btn-success btn-small">Искать</button>
	</form>
	</div>
	<div class="clearfix"></div>
  </div>
  </div>
</nav>
<div class="row-fluid static4r">
<aside class="span4">
	<div class="well">
		<h2>Департамент</h2>
		<ul class="nav nav-list text-black" id="accordion">
			<li><a href="#">Члены департамента</a></li>
			<li><a href="#">Председатели</a>
				<ul>
				  <li class="active"><a href="#">Председатели сос</a>
					<ul>
						<li><a href="#">Меню 3-го уровня</a></li>
						<li><a href="#">Еще меню 3-го уровня</a></li>
					</ul>
					</li>
				  <li><a href="#">Председатель ГЦР</a></li>
				</ul>
			</li>
			<li><a href="#">Гос. служащие</a></li>
			<li><a href="#">Постановления</a></li>
			<li><a href="#">Документы</a></li>
		</ul>
	</div>
	<div class="well" id="datepicker">
	  <h2>Календарь новостей</h2>
	</div>
	<div class="well lime lipetsk-dom-min" id="lipetsk-dom">
		<h2>Липецк-наш общий дом</h2>
		 <figure>
			<img src="img/foto6.jpg" alt="Программа «Помощи пенсионерам»" />
			<figcaption class="black">Программа «Помощи пенсионерам»</figcaption>
		 </figure>
		 <a href="#" class="btn btn-warning btn-mini">Все программы</a>
	</div>
	<div class="blue well">
	<h2>Фотогалерея</h2>
	<div id="myCarousel2" class="carousel slide slider-min">
		<div class="carousel-inner">
		<div class="active item">
			<figure>
			<img src="img/foto7.jpg" alt="Новое здание прокуратуры" />
			<figcaption class="black">Новое здание прокуратуры</figcaption>
			</figure>
		</div>
		<div class="item">…</div>
		<div class="item">…</div>
		</div>
		<a class="carousel-control left" href="#myCarousel2" data-slide="prev"></a>
		<a class="carousel-control right" href="#myCarousel2" data-slide="next"></a>
	</div>
	<p><a href="#" class="btn btn-primary btn-mini">Последнее мероприятие</a></p>
	<p><a href="#" class="btn btn-warning btn-mini">Вся фотогалерея</a></p>
	</div>
</aside>
<section class="span8">
<section id="content">
<article>
<ul class="breadcrumb">
	<li><a href="../">Главная</a><span class="divider">—</span></li>
	<li class="active">Архив новостей</li>
</ul>
<div class="page-header">Архив новостей</div>
<? 
$select = 'SELECT title,dates, news';
$from   = '  FROM arhiv';
$where  = '  WHERE dates="'.$dates.'"';
$data = array();


$queryResult = @mysql_query($select . $from . $where);
while($myrow = mysql_fetch_array ($queryResult))
{
printf ("<h1>%s</h1>
        <p class='date'>%s</p>
		<p>%s</p>
		",$myrow["title"],$myrow["dates"],$myrow["news"]);
}


mysql_close($conn);


?>

</article>
</section>
<div class="clearfix"></div>
<ul class="inline soc">
	<li><a id="ok" href="#"></a></li>
	<li><a id="twi" href="#"></a></li>
	<li><a id="fb" href="#"></a></li>
	<li><a id="vk" href="#"></a></li>
</ul>
</section>
</div>
<div class="clearfix"></div>

<div class="row-fluid" id="banners">
		<ul class="ap-justify">
		<li><a href="#"><img src="img/ban1.png" alt="" /></a></li>
		<li><a href="#"><img src="img/ban2.png" alt="" /></a></li>
		<li><a href="#"><img src="img/ban3.png" alt="" /></a></li>
		<li><a href="#"><img src="img/ban4.png" alt="" /></a></li>
		<li><a href="#"><img src="img/ban5.png" alt="" /></a></li>
		</ul>
</div>
  </div>
  </div>
  
<footer id="footer">
	<div class="row-fluid">
		<div class="container">
		<div class="span4">© 2013 Официальный сайт<br />Департамента территориального управления администрации города Липецка</div>
		<div class="span4 offset1">Телефоны<br />8 (4742) 23-13-30, 23-97-80, 8 (4742) 22-13-30<br /><a href="#">Обратная связь</a></div>
		<div class="pull-right">Адрес организации<br />Россия, 398059, г.Липецк, ул.Советская, 68<br /><a class="text-black" href="mailto:connect@cominfo.lipetsk.ru">connect@cominfo.lipetsk.ru</a></div>
		<div class="clearfix"></div>
	</div>
	</div>
</footer>

<script type="text/javascript" src="js/jquery.totemticker.min.js"></script>
<script type="text/javascript" src="js/jquery.formstyler.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body> 
</html>