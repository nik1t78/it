<?
if (isset($_GET['year'])) {$year =$_GET['year']; if ($year == '') { unset($year);}}
if (isset($_GET['month'])) {$month =$_GET['month']; if ($month == '') { unset($month);}}
$conn = @mysql_connect("localhost", "root", "");
 mysql_query ('SET NAMES utf8');
    mysql_query ('SET CHARACTER SET utf8');
if (!$conn)
  die("Error connecting to MySQL: " . mysql_error());

if (!mysql_select_db("cal", $conn))
  die("Error selecting Head First database: " . mysql_error());

$select = 'SELECT dates';
$from   = '  FROM arhiv';
$where  = '  WHERE YEAR(dates)='.$year.' AND MONTH(dates)='.$month;
$data = array();

$queryResult = @mysql_query($select . $from . $where);
$i=0;
while($row=mysql_fetch_array($queryResult))
	{  
		
		$data[$i]=$row['dates'];
		$i++;
	}

$resalt = json_encode($data);
echo $resalt;

mysql_close($conn);

?>