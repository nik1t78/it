<?php
header('Location: https://usp.admlr.lipetsk.ru/kiosk/kiosk.html', true, 301);
exit();
?>
