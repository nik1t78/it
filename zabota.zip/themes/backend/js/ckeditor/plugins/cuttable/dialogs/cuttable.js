/**
title - Заголовок диалогового окна
minWidth и minHeight - минимальные размеры диалогового окна
onOk - этот метов выполняется при нажатии на кнопку Ок диалогового окна. А делает он именно то, что и планировалось - получает из диалогового окна текст ссылки-ката и вставляет нужный элемент в редактируемый документ.
contents - массив вкладок диалогового окна с описанием форм во вкладках. В нашем диалогово окне одна вкладка с одним текстовым значением.
**/

CKEDITOR.dialog.add('cuttable', function(editor){
	return {
		title: 'Создать  Cut',
		minWidth : 400,
		minHeight : 200,
		onOk : function(){
			var cuttext = this.getContentElement( 'cut', 'cuttext' ).getInputElement().getValue();
			this._.editor.insertHtml('<iktomi-cut>' + cuttext + '</iktomi-cut>');
		},
		contents : [{
			id : 'cut',
			label : 'First Tab',
			title : 'First Tab',
			elements : [{
				id : 'cuttext',
				type : 'text',
				label : 'Текст ссылки'
			}]
		}]
	};
});