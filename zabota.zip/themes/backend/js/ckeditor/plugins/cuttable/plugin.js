/**
CKEDITOR.plugins.add(pluginName, plugin); - добавляем плагин с именем pluginName. В качестве второго аргумента принимается объект, реализующий плагин. В этом объекте обязательно должна присутствовать функция init, инициализирующая плагин. В нашем случае, объект состоит из одной этой функции. Разберем ее подробнее.

var command = editor.addCommand('cuttable', new CKEDITOR.dialogCommand('cuttable')); этой строчкой мы создали команду на создание диалога, и назвали ее cuttable. Следующими строками мы указываем, что эта команда должна работать как в режиме wysiwyg, так и в режиме просмотра исходников. а также возможность отмены действия.

editor.ui.addButton('cuttable', options); создаем кнопку на панели инструментов. И сразу же ее настраиваем, передав в качестве параметра options объект с тремя полями:
- label - название кнопки.
- command - вызываемая при нажатии кнопки команда
- icon - иконка кнопки.

CKEDITOR.dialog.add('cuttable', this.path+'dialogs/cuttable.js' ); - регистрируем диалог, указываея его название и путь до файла с его описанием.
**/


CKEDITOR.plugins.add('cuttable',{ 
	init : function(editor){
		var command = editor.addCommand('cuttable', new CKEDITOR.dialogCommand('cuttable'));
		command.modes = {wysiwyg:1, source:1};
		command.canUndo = true;
		
		editor.ui.addButton('Cuttable', {
			label : 'Создать Cut',
			command : 'cuttable',
			icon : '/your/path/to/icon/cut.png'
		});
		
		CKEDITOR.dialog.add('cuttable', this.path + 'dialogs/cuttable.js');
	}
});